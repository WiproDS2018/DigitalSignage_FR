﻿dsControllers.controller('homePageController', function ($scope, $rootScope, settingService, $q, $uibModal, $http, myService) {
    console.log("Home page");
    $rootScope.parentBgHome = false;
})